import React from 'react';
import FicheCout from './FicheCout';

function App() {
  return <FicheCout />;
}

export default App;
