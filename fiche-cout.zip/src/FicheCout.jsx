import React, { useState } from 'react';

const defaultDevise = 'Ariary';

const initialSubSections = {
  'Matières premières': [],
  'Main d'œuvre directe': [],
  'Charges indirectes de production': [],
  'Coûts de distribution': [],
  'Coûts d'administration': [],
};

const sousRubriquesProduction = ['Matières premières', 'Main d'œuvre directe', 'Charges indirectes de production'];
const sousRubriquesHorsProduction = ['Coûts de distribution', 'Coûts d'administration'];

const postesExemple = ['Emballage', 'Transport', 'Électricité'];
const unitesExemple = ['kg', 'heure', 'unité'];

const FicheCout = () => {
  const [devise, setDevise] = useState(defaultDevise);
  const [sections, setSections] = useState(initialSubSections);

  const addLigne = (rubrique) => {
    const nouvelleLigne = { poste: '', unite: '', quantite: 0, coutUnitaire: 0 };
    setSections(prev => ({
      ...prev,
      [rubrique]: [...prev[rubrique], nouvelleLigne]
    }));
  };

  const updateLigne = (rubrique, index, field, value) => {
    const lignes = [...sections[rubrique]];
    lignes[index][field] = field === 'quantite' || field === 'coutUnitaire' ? parseFloat(value) || 0 : value;
    setSections(prev => ({
      ...prev,
      [rubrique]: lignes
    }));
  };

  const calculMontant = (ligne) => {
    return ligne.quantite * ligne.coutUnitaire;
  };

  const calculTotalRubrique = (rubriques) => {
    return rubriques.reduce((total, rubrique) => {
      return total + sections[rubrique].reduce((sousTotal, ligne) => sousTotal + calculMontant(ligne), 0);
    }, 0);
  };

  const totalProduction = calculTotalRubrique(sousRubriquesProduction);
  const totalHorsProduction = calculTotalRubrique(sousRubriquesHorsProduction);
  const totalGlobal = totalProduction + totalHorsProduction;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Fiche de coût de revient</h1>

      <div className="mb-4">
        <label className="mr-2 font-medium">Devise :</label>
        <select value={devise} onChange={e => setDevise(e.target.value)} className="border p-1 rounded">
          <option value="Ariary">Ariary</option>
          <option value="€">€</option>
          <option value="$">$</option>
        </select>
      </div>

      {[...sousRubriquesProduction, ...sousRubriquesHorsProduction].map(rubrique => (
        <div key={rubrique} className="mb-6 border-t pt-4">
          <h2 className="text-lg font-semibold">{rubrique}</h2>
          <table className="w-full mt-2 text-sm border">
            <thead>
              <tr className="bg-gray-100">
                <th className="p-2 border">Poste de coûts</th>
                <th className="p-2 border">Unité</th>
                <th className="p-2 border">Quantité</th>
                <th className="p-2 border">Coût unitaire</th>
                <th className="p-2 border">Montant ({devise})</th>
              </tr>
            </thead>
            <tbody>
              {sections[rubrique].map((ligne, index) => (
                <tr key={index}>
                  <td className="border">
                    <select
                      className="w-full p-1"
                      value={ligne.poste}
                      onChange={e => updateLigne(rubrique, index, 'poste', e.target.value)}
                    >
                      <option value="">-- Sélectionner --</option>
                      {postesExemple.map(poste => <option key={poste} value={poste}>{poste}</option>)}
                    </select>
                  </td>
                  <td className="border">
                    <select
                      className="w-full p-1"
                      value={ligne.unite}
                      onChange={e => updateLigne(rubrique, index, 'unite', e.target.value)}
                    >
                      <option value="">-- Unité --</option>
                      {unitesExemple.map(unite => <option key={unite} value={unite}>{unite}</option>)}
                    </select>
                  </td>
                  <td className="border"><input type="number" className="w-full p-1" value={ligne.quantite} onChange={e => updateLigne(rubrique, index, 'quantite', e.target.value)} /></td>
                  <td className="border"><input type="number" className="w-full p-1" value={ligne.coutUnitaire} onChange={e => updateLigne(rubrique, index, 'coutUnitaire', e.target.value)} /></td>
                  <td className="border p-2 text-right">{calculMontant(ligne).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <button onClick={() => addLigne(rubrique)} className="mt-2 px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600">
            + Ajouter une ligne
          </button>
        </div>
      ))}

      <div className="mt-6 text-right space-y-2">
        <p><strong>Sous-total coût de production :</strong> {totalProduction.toFixed(2)} {devise}</p>
        <p><strong>Sous-total hors production :</strong> {totalHorsProduction.toFixed(2)} {devise}</p>
        <p className="text-lg font-bold border-t pt-2 mt-2"><strong>Coût de revient total :</strong> {totalGlobal.toFixed(2)} {devise}</p>
      </div>
    </div>
  );
};

export default FicheCout;
